# Student Attendance Manager

## Overview

This is a full-stack Student Attendance Management System built with a modern React frontend and Express.js backend. The application allows users to manage student records, track daily attendance, view attendance records, and generate reports with PDF export capabilities. Data is stored locally in the browser using localStorage for persistence.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: React hooks with TanStack Query for server state
- **UI Framework**: Shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming
- **Build Tool**: Vite for fast development and optimized builds

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Server Setup**: Custom HTTP server with middleware for logging and error handling
- **Development**: Hot module replacement via Vite integration
- **Storage**: In-memory storage with interface for future database integration

### Data Storage
- **Client-side**: localStorage for persistent data storage
- **Schema**: Drizzle ORM configured for PostgreSQL (ready for future database integration)
- **Data Models**: Student records and attendance records with proper TypeScript typing

## Key Components

### Frontend Components
- **AttendanceDashboard**: Main application container with tab-based navigation
- **StudentsTab**: Manage student registration and removal
- **AttendanceTab**: Daily attendance marking interface
- **RecordsTab**: View and search attendance history
- **ReportsTab**: Generate attendance summaries and individual reports

### Backend Components
- **Storage Interface**: Abstracted storage layer with in-memory implementation
- **Routes**: Express routes configured for API endpoints
- **Middleware**: Request logging and error handling

### UI Components
- Complete Shadcn/ui component library
- Custom toast notification system
- Mobile-responsive design with custom hooks

## Data Flow

1. **Student Management**: Add/remove students with unique IDs and names
2. **Attendance Tracking**: Mark daily attendance (present/absent) for all students
3. **Data Persistence**: All data stored in localStorage with automatic serialization
4. **Report Generation**: Calculate attendance percentages and export to PDF
5. **Search and Filter**: Filter records by date and student

## External Dependencies

### Core Dependencies
- **React Ecosystem**: React, React DOM, React Hook Form
- **UI Components**: Radix UI primitives, Lucide React icons
- **Data Handling**: Zod for validation, TanStack Query for state management
- **PDF Generation**: jsPDF with autoTable plugin
- **Date Handling**: date-fns for date utilities
- **Styling**: Tailwind CSS, class-variance-authority for component variants

### Development Dependencies
- **Build Tools**: Vite, esbuild for production builds
- **Database**: Drizzle ORM with PostgreSQL adapter (Neon serverless)
- **TypeScript**: Full TypeScript support with strict configuration

## Deployment Strategy

### Development
- Vite dev server with hot module replacement
- Express server running on Node.js
- Environment variables for database configuration

### Production
- Frontend built to static assets via Vite
- Backend bundled with esbuild
- Single deployable application serving both frontend and API
- PostgreSQL database ready for production deployment

### Database Migration
- Drizzle configured for PostgreSQL with migration support
- Schema defined in shared directory for type safety
- Ready to migrate from localStorage to database storage

The application is architected for easy scaling from a local storage prototype to a full database-backed production system while maintaining type safety and a consistent development experience.