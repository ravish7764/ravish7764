import { z } from "zod";

export const studentSchema = z.object({
  id: z.string(),
  name: z.string().min(1, "Student name is required"),
  dateAdded: z.string(),
});

export const attendanceRecordSchema = z.object({
  id: z.string(),
  date: z.string(),
  studentId: z.string(),
  studentName: z.string(),
  status: z.enum(["present", "absent"]),
  timestamp: z.string(),
});

export const insertStudentSchema = studentSchema.omit({ dateAdded: true });
export const insertAttendanceRecordSchema = attendanceRecordSchema.omit({ timestamp: true });

export type Student = z.infer<typeof studentSchema>;
export type AttendanceRecord = z.infer<typeof attendanceRecordSchema>;
export type InsertStudent = z.infer<typeof insertStudentSchema>;
export type InsertAttendanceRecord = z.infer<typeof insertAttendanceRecordSchema>;

export interface AttendanceSummary {
  student: Student;
  totalDays: number;
  presentDays: number;
  absentDays: number;
  percentage: number;
}
