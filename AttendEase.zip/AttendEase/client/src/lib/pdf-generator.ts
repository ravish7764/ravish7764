import jsPDF from 'jspdf';
import 'jspdf-autotable';
import { Student, AttendanceRecord, AttendanceSummary } from '@shared/schema';

// Extend jsPDF type to include autoTable
declare module 'jspdf' {
  interface jsPDF {
    autoTable: (options: any) => jsPDF;
  }
}

export function generateSummaryPDF(summaries: AttendanceSummary[], totalTeachingDays: number) {
  const doc = new jsPDF();
  
  // Title
  doc.setFontSize(20);
  doc.text('Attendance Summary Report', 20, 20);
  
  // Date and teaching days
  doc.setFontSize(12);
  doc.text(`Generated on: ${new Date().toLocaleDateString()}`, 20, 30);
  doc.text(`Total Teaching Days: ${totalTeachingDays}`, 20, 40);
  
  // Prepare table data
  const tableData = summaries.map(summary => [
    summary.student.name,
    summary.student.id,
    summary.presentDays.toString(),
    summary.absentDays.toString(),
    summary.totalDays.toString(),
    `${summary.percentage.toFixed(1)}%`
  ]);
  
  // Add table
  doc.autoTable({
    head: [['Student Name', 'ID', 'Present', 'Absent', 'Total', 'Percentage']],
    body: tableData,
    startY: 50,
    styles: { fontSize: 10 },
    headStyles: { fillColor: [25, 118, 210] }
  });
  
  doc.save('attendance-summary.pdf');
}

export function generateIndividualPDF(
  student: Student, 
  records: AttendanceRecord[], 
  summary: AttendanceSummary
) {
  const doc = new jsPDF();
  
  // Title
  doc.setFontSize(20);
  doc.text('Individual Attendance Report', 20, 20);
  
  // Student info
  doc.setFontSize(14);
  doc.text(`Student: ${student.name}`, 20, 35);
  doc.text(`ID: ${student.id}`, 20, 45);
  doc.text(`Generated on: ${new Date().toLocaleDateString()}`, 20, 55);
  
  // Summary
  doc.setFontSize(12);
  doc.text(`Total Days: ${summary.totalDays}`, 20, 70);
  doc.text(`Present: ${summary.presentDays}`, 20, 80);
  doc.text(`Absent: ${summary.absentDays}`, 20, 90);
  doc.text(`Attendance Percentage: ${summary.percentage.toFixed(1)}%`, 20, 100);
  
  // Detailed records
  if (records.length > 0) {
    const tableData = records
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
      .map(record => [
        new Date(record.date).toLocaleDateString(),
        record.status.charAt(0).toUpperCase() + record.status.slice(1)
      ]);
    
    doc.autoTable({
      head: [['Date', 'Status']],
      body: tableData,
      startY: 110,
      styles: { fontSize: 10 },
      headStyles: { fillColor: [25, 118, 210] }
    });
  }
  
  doc.save(`${student.name}-attendance-report.pdf`);
}

export function exportAttendanceData(students: Student[], records: AttendanceRecord[]) {
  const data = {
    students,
    attendanceRecords: records,
    exportDate: new Date().toISOString()
  };
  
  const dataStr = JSON.stringify(data, null, 2);
  const dataBlob = new Blob([dataStr], { type: 'application/json' });
  
  const link = document.createElement('a');
  link.href = URL.createObjectURL(dataBlob);
  link.download = `attendance-data-${new Date().toISOString().split('T')[0]}.json`;
  link.click();
}
