import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Search, X, Trash2, FileText } from "lucide-react";
import { AttendanceRecord } from "@shared/schema";
import { showToast } from "@/components/ui/toast-notification";

interface RecordsTabProps {
  attendanceRecords: AttendanceRecord[];
  onDeleteRecord: (recordId: string) => void;
}

export default function RecordsTab({ attendanceRecords, onDeleteRecord }: RecordsTabProps) {
  const [searchDate, setSearchDate] = useState("");

  const filteredRecords = searchDate
    ? attendanceRecords.filter(record => record.date === searchDate)
    : attendanceRecords;

  const sortedRecords = [...filteredRecords].sort((a, b) => 
    new Date(b.date).getTime() - new Date(a.date).getTime()
  );

  const handleDelete = (recordId: string) => {
    if (window.confirm('Are you sure you want to delete this attendance record?')) {
      onDeleteRecord(recordId);
      showToast("Record deleted successfully!");
    }
  };

  const clearSearch = () => {
    setSearchDate("");
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Attendance Records
            </CardTitle>
            <CardDescription>
              View and manage all attendance records
            </CardDescription>
          </div>
          <div className="flex items-center gap-2">
            <div className="space-y-2">
              <Label htmlFor="searchDate">Search by Date</Label>
              <div className="flex items-center gap-2">
                <Input
                  id="searchDate"
                  type="date"
                  value={searchDate}
                  onChange={(e) => setSearchDate(e.target.value)}
                  placeholder="Select date"
                />
                {searchDate && (
                  <Button variant="outline" size="sm" onClick={clearSearch}>
                    <X className="h-4 w-4" />
                  </Button>
                )}
              </div>
            </div>
          </div>
        </div>
        
        <div className="flex items-center gap-4 text-sm">
          <Badge variant="secondary">
            {filteredRecords.length} record{filteredRecords.length !== 1 ? 's' : ''}
          </Badge>
          {searchDate && (
            <span className="text-muted-foreground">
              Showing results for {new Date(searchDate).toLocaleDateString()}
            </span>
          )}
        </div>
      </CardHeader>
      <CardContent>
        {sortedRecords.length === 0 ? (
          <div className="text-center py-8">
            <Search className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <p className="text-muted-foreground">
              {searchDate ? "No records found for this date." : "No attendance records found."}
            </p>
          </div>
        ) : (
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Student</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {sortedRecords.map((record) => (
                  <TableRow key={record.id}>
                    <TableCell className="font-medium">
                      {new Date(record.date).toLocaleDateString()}
                    </TableCell>
                    <TableCell>
                      <div>
                        <p className="font-medium">{record.studentName}</p>
                        <p className="text-sm text-muted-foreground">ID: {record.studentId}</p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge 
                        variant={record.status === 'present' ? 'default' : 'destructive'}
                        className={record.status === 'present' ? 'bg-green-100 text-green-800 hover:bg-green-100' : ''}
                      >
                        {record.status.charAt(0).toUpperCase() + record.status.slice(1)}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDelete(record.id)}
                        className="text-destructive hover:text-destructive hover:bg-destructive/10"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
