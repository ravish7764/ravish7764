import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Calendar, Save } from "lucide-react";
import { Student, AttendanceRecord, InsertAttendanceRecord } from "@shared/schema";
import { showToast } from "@/components/ui/toast-notification";

interface AttendanceTabProps {
  students: Student[];
  attendanceRecords: AttendanceRecord[];
  onSaveAttendance: (records: InsertAttendanceRecord[]) => void;
}

export default function AttendanceTab({ students, attendanceRecords, onSaveAttendance }: AttendanceTabProps) {
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [attendance, setAttendance] = useState<Record<string, "present" | "absent" | "">>({});

  // Load existing attendance for selected date
  useEffect(() => {
    const existingAttendance: Record<string, "present" | "absent" | ""> = {};
    
    students.forEach(student => {
      const record = attendanceRecords.find(
        r => r.date === selectedDate && r.studentId === student.id
      );
      existingAttendance[student.id] = record ? record.status : "";
    });
    
    setAttendance(existingAttendance);
  }, [selectedDate, students, attendanceRecords]);

  const handleAttendanceChange = (studentId: string, status: "present" | "absent") => {
    setAttendance(prev => ({
      ...prev,
      [studentId]: status
    }));
  };

  const handleSave = () => {
    if (!selectedDate) {
      showToast("Please select a date", "error");
      return;
    }

    const records: InsertAttendanceRecord[] = [];
    let hasAttendance = false;

    students.forEach(student => {
      const status = attendance[student.id];
      if (status) {
        hasAttendance = true;
        records.push({
          id: `${selectedDate}-${student.id}`,
          date: selectedDate,
          studentId: student.id,
          studentName: student.name,
          status
        });
      }
    });

    if (!hasAttendance) {
      showToast("Please mark attendance for at least one student", "warning");
      return;
    }

    onSaveAttendance(records);
    showToast(`Attendance saved for ${records.length} student${records.length !== 1 ? 's' : ''}!`);
  };

  const getAttendanceCount = () => {
    const present = Object.values(attendance).filter(status => status === "present").length;
    const absent = Object.values(attendance).filter(status => status === "absent").length;
    return { present, absent, total: present + absent };
  };

  const counts = getAttendanceCount();

  return (
    <Card>
      <CardHeader>
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5" />
              Mark Attendance
            </CardTitle>
            <CardDescription>
              Record student attendance for the selected date
            </CardDescription>
          </div>
          <div className="flex items-center gap-4">
            <div className="space-y-2">
              <Label htmlFor="attendanceDate">Date</Label>
              <Input
                id="attendanceDate"
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
              />
            </div>
            <Button onClick={handleSave} className="self-end">
              <Save className="h-4 w-4 mr-2" />
              Save Attendance
            </Button>
          </div>
        </div>
        
        {counts.total > 0 && (
          <div className="flex gap-4 text-sm">
            <span className="text-green-600">Present: {counts.present}</span>
            <span className="text-red-600">Absent: {counts.absent}</span>
            <span className="text-muted-foreground">Total: {counts.total}</span>
          </div>
        )}
      </CardHeader>
      <CardContent>
        {students.length === 0 ? (
          <p className="text-muted-foreground text-sm text-center py-8">
            No students registered. Please add students first to mark attendance.
          </p>
        ) : (
          <div className="space-y-4">
            {students.map((student) => (
              <div
                key={student.id}
                className="flex items-center justify-between p-4 bg-muted rounded-lg"
              >
                <div>
                  <p className="font-medium text-foreground">{student.name}</p>
                  <p className="text-sm text-muted-foreground">ID: {student.id}</p>
                </div>
                <RadioGroup
                  value={attendance[student.id] || ""}
                  onValueChange={(value) => handleAttendanceChange(student.id, value as "present" | "absent")}
                  className="flex items-center space-x-6"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="present" id={`${student.id}-present`} />
                    <Label htmlFor={`${student.id}-present`} className="text-green-600">
                      Present
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="absent" id={`${student.id}-absent`} />
                    <Label htmlFor={`${student.id}-absent`} className="text-red-600">
                      Absent
                    </Label>
                  </div>
                </RadioGroup>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
