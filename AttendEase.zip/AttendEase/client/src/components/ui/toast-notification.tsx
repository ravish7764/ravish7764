import { useToast } from "@/hooks/use-toast";
import { CheckCircle, XCircle, AlertCircle, Info } from "lucide-react";

export interface ToastNotificationProps {
  message: string;
  type?: "success" | "error" | "warning" | "info";
}

export function showToast(message: string, type: "success" | "error" | "warning" | "info" = "success") {
  const { toast } = useToast();
  
  const icons = {
    success: CheckCircle,
    error: XCircle,
    warning: AlertCircle,
    info: Info
  };
  
  const colors = {
    success: "text-green-600",
    error: "text-red-600", 
    warning: "text-yellow-600",
    info: "text-blue-600"
  };
  
  const Icon = icons[type];
  
  toast({
    title: (
      <div className="flex items-center gap-2">
        <Icon className={`h-5 w-5 ${colors[type]}`} />
        <span>{message}</span>
      </div>
    ) as any,
    duration: 3000,
  });
}
