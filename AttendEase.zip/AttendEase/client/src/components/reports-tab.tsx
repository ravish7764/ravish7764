import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { BarChart3, Download, FileText, User } from "lucide-react";
import { Student, AttendanceRecord, AttendanceSummary } from "@shared/schema";
import { generateSummaryPDF, generateIndividualPDF } from "@/lib/pdf-generator";
import { showToast } from "@/components/ui/toast-notification";

interface ReportsTabProps {
  students: Student[];
  attendanceRecords: AttendanceRecord[];
}

export default function ReportsTab({ students, attendanceRecords }: ReportsTabProps) {
  const [selectedStudentId, setSelectedStudentId] = useState<string>("");

  // Calculate attendance summaries
  const summaries: AttendanceSummary[] = students.map(student => {
    const studentRecords = attendanceRecords.filter(record => record.studentId === student.id);
    const presentDays = studentRecords.filter(record => record.status === 'present').length;
    const absentDays = studentRecords.filter(record => record.status === 'absent').length;
    const totalDays = studentRecords.length;
    const percentage = totalDays > 0 ? (presentDays / totalDays) * 100 : 0;

    return {
      student,
      totalDays,
      presentDays,
      absentDays,
      percentage
    };
  });

  // Calculate total teaching days
  const uniqueDates = [...new Set(attendanceRecords.map(record => record.date))];
  const totalTeachingDays = uniqueDates.length;

  const handleDownloadSummary = () => {
    if (summaries.length === 0) {
      showToast("No data available for summary report", "warning");
      return;
    }
    
    generateSummaryPDF(summaries, totalTeachingDays);
    showToast("Summary PDF downloaded successfully!");
  };

  const handleDownloadIndividual = () => {
    if (!selectedStudentId) {
      showToast("Please select a student", "warning");
      return;
    }

    const student = students.find(s => s.id === selectedStudentId);
    const studentRecords = attendanceRecords.filter(r => r.studentId === selectedStudentId);
    const summary = summaries.find(s => s.student.id === selectedStudentId);

    if (!student || !summary) {
      showToast("Student data not found", "error");
      return;
    }

    generateIndividualPDF(student, studentRecords, summary);
    showToast("Individual report downloaded successfully!");
  };

  const getAttendanceColor = (percentage: number) => {
    if (percentage >= 75) return "text-green-600";
    if (percentage >= 50) return "text-yellow-600";
    return "text-red-600";
  };

  const getProgressColor = (percentage: number) => {
    if (percentage >= 75) return "bg-green-500";
    if (percentage >= 50) return "bg-yellow-500";
    return "bg-red-500";
  };

  const selectedSummary = summaries.find(s => s.student.id === selectedStudentId);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Summary Report */}
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5" />
                Attendance Summary
              </CardTitle>
              <CardDescription>
                Overview of all students' attendance
              </CardDescription>
            </div>
            <Button onClick={handleDownloadSummary} size="sm">
              <Download className="h-4 w-4 mr-2" />
              Download PDF
            </Button>
          </div>
          
          <div className="bg-blue-50 dark:bg-blue-950 rounded-lg p-4">
            <div className="flex items-center gap-3">
              <FileText className="h-6 w-6 text-blue-600" />
              <div>
                <p className="font-semibold text-blue-900 dark:text-blue-100">Total Teaching Days</p>
                <p className="text-blue-600 dark:text-blue-300">{totalTeachingDays} days</p>
              </div>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4 max-h-96 overflow-y-auto">
            {summaries.length === 0 ? (
              <p className="text-muted-foreground text-sm text-center py-8">
                No attendance data available yet.
              </p>
            ) : (
              summaries.map((summary) => (
                <div key={summary.student.id} className="bg-muted rounded-lg p-4">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h3 className="font-medium text-foreground">{summary.student.name}</h3>
                      <p className="text-sm text-muted-foreground">ID: {summary.student.id}</p>
                    </div>
                    <span className={`text-lg font-bold ${getAttendanceColor(summary.percentage)}`}>
                      {summary.percentage.toFixed(1)}%
                    </span>
                  </div>
                  <div className="grid grid-cols-3 gap-4 text-sm mb-3">
                    <div>
                      <span className="text-muted-foreground">Present:</span>
                      <span className="ml-1 font-medium text-green-600">{summary.presentDays}</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Absent:</span>
                      <span className="ml-1 font-medium text-red-600">{summary.absentDays}</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Total:</span>
                      <span className="ml-1 font-medium">{summary.totalDays}</span>
                    </div>
                  </div>
                  <div className="relative">
                    <Progress value={summary.percentage} className="h-2" />
                    <div 
                      className={`absolute top-0 left-0 h-2 rounded-full transition-all ${getProgressColor(summary.percentage)}`}
                      style={{ width: `${summary.percentage}%` }}
                    />
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      {/* Individual Student Report */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <User className="h-5 w-5" />
            Individual Student Report
          </CardTitle>
          <CardDescription>
            Generate detailed report for a specific student
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <label htmlFor="studentSelect" className="text-sm font-medium">
              Select Student
            </label>
            <Select value={selectedStudentId} onValueChange={setSelectedStudentId}>
              <SelectTrigger>
                <SelectValue placeholder="Choose a student..." />
              </SelectTrigger>
              <SelectContent>
                {students.map((student) => (
                  <SelectItem key={student.id} value={student.id}>
                    {student.name} ({student.id})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {selectedSummary && (
            <div className="space-y-4">
              <div className="bg-muted rounded-lg p-4">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="font-medium text-muted-foreground">Total Days:</span>
                    <span className="ml-2 text-foreground">{selectedSummary.totalDays}</span>
                  </div>
                  <div>
                    <span className="font-medium text-muted-foreground">Present:</span>
                    <span className="ml-2 text-green-600">{selectedSummary.presentDays}</span>
                  </div>
                  <div>
                    <span className="font-medium text-muted-foreground">Absent:</span>
                    <span className="ml-2 text-red-600">{selectedSummary.absentDays}</span>
                  </div>
                  <div>
                    <span className="font-medium text-muted-foreground">Percentage:</span>
                    <span className={`ml-2 font-semibold ${getAttendanceColor(selectedSummary.percentage)}`}>
                      {selectedSummary.percentage.toFixed(1)}%
                    </span>
                  </div>
                </div>
              </div>
              
              <Button onClick={handleDownloadIndividual} className="w-full">
                <Download className="h-4 w-4 mr-2" />
                Download Individual Report
              </Button>
            </div>
          )}

          {!selectedStudentId && students.length > 0 && (
            <p className="text-muted-foreground text-sm text-center py-8">
              Select a student to view their detailed report.
            </p>
          )}

          {students.length === 0 && (
            <p className="text-muted-foreground text-sm text-center py-8">
              No students available. Please add students first.
            </p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
