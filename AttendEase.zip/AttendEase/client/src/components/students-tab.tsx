import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Trash2, UserPlus } from "lucide-react";
import { Student, InsertStudent } from "@shared/schema";
import { showToast } from "@/components/ui/toast-notification";

interface StudentsTabProps {
  students: Student[];
  onAddStudent: (student: InsertStudent) => void;
  onRemoveStudent: (studentId: string) => void;
}

export default function StudentsTab({ students, onAddStudent, onRemoveStudent }: StudentsTabProps) {
  const [name, setName] = useState("");
  const [id, setId] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!name.trim() || !id.trim()) {
      showToast("Please fill in all fields", "error");
      return;
    }

    // Check if student ID already exists
    if (students.find(s => s.id === id.trim())) {
      showToast("Student ID already exists!", "error");
      return;
    }

    onAddStudent({
      name: name.trim(),
      id: id.trim()
    });

    setName("");
    setId("");
    showToast("Student added successfully!");
  };

  const handleRemove = (studentId: string) => {
    if (window.confirm('Are you sure you want to remove this student? This will also remove all their attendance records.')) {
      onRemoveStudent(studentId);
      showToast("Student removed successfully!");
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Add Student Form */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <UserPlus className="h-5 w-5" />
            Add New Student
          </CardTitle>
          <CardDescription>
            Register a new student in the attendance system
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="studentName">Student Name</Label>
              <Input
                id="studentName"
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Enter student name"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="studentId">Student ID</Label>
              <Input
                id="studentId"
                type="text"
                value={id}
                onChange={(e) => setId(e.target.value)}
                placeholder="Enter student ID"
                required
              />
            </div>
            <Button type="submit" className="w-full">
              Add Student
            </Button>
          </form>
        </CardContent>
      </Card>

      {/* Students List */}
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle>Registered Students</CardTitle>
              <CardDescription>
                Manage your students
              </CardDescription>
            </div>
            <Badge variant="secondary">
              {students.length} student{students.length !== 1 ? 's' : ''}
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3 max-h-96 overflow-y-auto">
            {students.length === 0 ? (
              <p className="text-muted-foreground text-sm text-center py-8">
                No students registered yet. Add your first student to get started.
              </p>
            ) : (
              students.map((student) => (
                <div
                  key={student.id}
                  className="flex items-center justify-between p-3 bg-muted rounded-lg"
                >
                  <div>
                    <p className="font-medium text-foreground">{student.name}</p>
                    <p className="text-sm text-muted-foreground">ID: {student.id}</p>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleRemove(student.id)}
                    className="text-destructive hover:text-destructive hover:bg-destructive/10"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
