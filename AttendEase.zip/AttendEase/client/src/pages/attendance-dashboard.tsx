import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { FileText, Download, Calendar } from "lucide-react";
import { Student, AttendanceRecord, InsertStudent, InsertAttendanceRecord } from "@shared/schema";
import { useLocalStorage } from "@/hooks/use-local-storage";
import { exportAttendanceData } from "@/lib/pdf-generator";
import { showToast } from "@/components/ui/toast-notification";
import StudentsTab from "@/components/students-tab";
import AttendanceTab from "@/components/attendance-tab";
import RecordsTab from "@/components/records-tab";
import ReportsTab from "@/components/reports-tab";

export default function AttendanceDashboard() {
  const [students, setStudents] = useLocalStorage<Student[]>("students", []);
  const [attendanceRecords, setAttendanceRecords] = useLocalStorage<AttendanceRecord[]>("attendanceRecords", []);
  const [activeTab, setActiveTab] = useState("students");

  const handleAddStudent = (insertStudent: InsertStudent) => {
    const newStudent: Student = {
      ...insertStudent,
      dateAdded: new Date().toISOString()
    };
    setStudents(prev => [...prev, newStudent]);
  };

  const handleRemoveStudent = (studentId: string) => {
    setStudents(prev => prev.filter(s => s.id !== studentId));
    // Also remove all attendance records for this student
    setAttendanceRecords(prev => prev.filter(r => r.studentId !== studentId));
  };

  const handleSaveAttendance = (records: InsertAttendanceRecord[]) => {
    const newRecords: AttendanceRecord[] = records.map(record => ({
      ...record,
      timestamp: new Date().toISOString()
    }));

    setAttendanceRecords(prev => {
      // Remove existing records for the same date and students
      const filtered = prev.filter(existing => 
        !newRecords.some(newRecord => 
          newRecord.date === existing.date && newRecord.studentId === existing.studentId
        )
      );
      return [...filtered, ...newRecords];
    });
  };

  const handleDeleteRecord = (recordId: string) => {
    setAttendanceRecords(prev => prev.filter(r => r.id !== recordId));
  };

  const handleExportData = () => {
    exportAttendanceData(students, attendanceRecords);
    showToast("Data exported successfully!");
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card shadow-sm border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <FileText className="h-8 w-8 text-primary" />
              </div>
              <div className="ml-4">
                <h1 className="text-xl font-semibold text-foreground">Student Attendance Manager</h1>
                <p className="text-sm text-muted-foreground">Track and manage student attendance records</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-muted-foreground">
                {new Date().toLocaleDateString()}
              </span>
              <Button variant="outline" onClick={handleExportData}>
                <Download className="h-4 w-4 mr-2" />
                Export Data
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="students" className="flex items-center gap-2">
              <span className="hidden sm:inline">Students</span>
              <span className="sm:hidden">👥</span>
            </TabsTrigger>
            <TabsTrigger value="attendance" className="flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              <span className="hidden sm:inline">Mark Attendance</span>
              <span className="sm:hidden">✓</span>
            </TabsTrigger>
            <TabsTrigger value="records" className="flex items-center gap-2">
              <span className="hidden sm:inline">Records</span>
              <span className="sm:hidden">📋</span>
            </TabsTrigger>
            <TabsTrigger value="reports" className="flex items-center gap-2">
              <span className="hidden sm:inline">Reports</span>
              <span className="sm:hidden">📊</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="students">
            <StudentsTab
              students={students}
              onAddStudent={handleAddStudent}
              onRemoveStudent={handleRemoveStudent}
            />
          </TabsContent>

          <TabsContent value="attendance">
            <AttendanceTab
              students={students}
              attendanceRecords={attendanceRecords}
              onSaveAttendance={handleSaveAttendance}
            />
          </TabsContent>

          <TabsContent value="records">
            <RecordsTab
              attendanceRecords={attendanceRecords}
              onDeleteRecord={handleDeleteRecord}
            />
          </TabsContent>

          <TabsContent value="reports">
            <ReportsTab
              students={students}
              attendanceRecords={attendanceRecords}
            />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
